public class LC0115_DistinctSubsequences {
    public int numDistinct(String s, String t) {
        int m = s.length(), n = t.length();
        long[][] dp = new long[m + 1][n + 1];
        for (int i = 0; i <= m; i++) dp[i][0] = 1;
        for (int i = 1; i <= m; i++)
            for (int j = 1; j <= n; j++) {
                dp[i][j] = dp[i-1][j];
                if (s.charAt(i-1) == t.charAt(j-1)) dp[i][j] += dp[i-1][j-1];
            }
        return (int) dp[m][n];
    }
    public static void main(String[] args) {
        LC0115_DistinctSubsequences sol = new LC0115_DistinctSubsequences();
        System.out.println(sol.numDistinct("rabbbit", "rabbit")); // 3
    }
}
