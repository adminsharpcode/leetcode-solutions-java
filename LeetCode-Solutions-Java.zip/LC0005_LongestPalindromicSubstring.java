/**
 * LeetCode 5: Longest Palindromic Substring
 * Difficulty: Medium
 * Link: https://leetcode.com/problems/longest-palindromic-substring/
 *
 * Approach: Expand Around Center
 * Time Complexity: O(N^2)
 * Space Complexity: O(1)
 */
public class LC0005_LongestPalindromicSubstring {

    public String longestPalindrome(String s) {
        if (s == null || s.length() < 1) return "";
        int start = 0, end = 0;

        for (int i = 0; i < s.length(); i++) {
            int len1 = expandAroundCenter(s, i, i);     // odd length
            int len2 = expandAroundCenter(s, i, i + 1); // even length
            int len = Math.max(len1, len2);
            if (len > end - start) {
                start = i - (len - 1) / 2;
                end = i + len / 2;
            }
        }

        return s.substring(start, end + 1);
    }

    private int expandAroundCenter(String s, int left, int right) {
        while (left >= 0 && right < s.length() && s.charAt(left) == s.charAt(right)) {
            left--;
            right++;
        }
        return right - left - 1;
    }

    public static void main(String[] args) {
        LC0005_LongestPalindromicSubstring solver = new LC0005_LongestPalindromicSubstring();
        System.out.println("babad -> " + solver.longestPalindrome("babad")); // Expected: "bab" or "aba"
        System.out.println("cbbd  -> " + solver.longestPalindrome("cbbd"));  // Expected: "bb"
    }
}
